SUPPLEMENTARY TABLES FOR PRJNA1002351 REANALYSIS

Supplementary Table S1: Supplementary_Table_S1_Master_Metadata.csv
- 196 rows, 28 columns.
- One row per SRA run record.
- Sample_ID (S001-S196) is a sequential display identifier assigned after sorting by numeric SRR accession.
- Group is derived from the sample-name prefix: D = DNA-derived; R = RNA-derived.
- All remaining fields are drawn from the accession-linked NCBI/SRA metadata export.
- Empty source metadata values are retained as blank; no missing values have been inferred.

Supplementary Table S2: Supplementary_Table_S2_Genus_Results.csv
- 206 genus-level rows, 18 columns.
- Includes prevalence/count summaries, CLR summaries, unadjusted Wilcoxon statistics, date-adjusted HC3 regression estimates, robust standard errors, 95% confidence intervals, P-values and BH-adjusted q-values.
- Primary date-adjusted model is restricted to the four shared collection dates and the 160-run subset.
- 98 of 206 genera have date-adjusted BH q < 0.05.
- Positive RNA_minus_DNA_adjusted_CLR_beta indicates higher CLR in RNA-derived profiles; negative values indicate higher CLR in DNA-derived profiles.

These tables are supplementary outputs of the computational reanalysis. Original sequencing reads remain available through NCBI BioProject PRJNA1002351 / SRA Study SRP453394.
