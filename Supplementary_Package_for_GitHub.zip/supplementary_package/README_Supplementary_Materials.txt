SUPPLEMENTARY MATERIALS
Study: Microbial Community Structure in Microplastic-Associated Biofilms: A Computational Reanalysis of Publicly Available 16S rRNA Data
BioProject: PRJNA1002351 | SRA Study: SRP453394

Contents
S1_Accession_Crosswalk.csv / .xlsx
  Accession crosswalk with 196 records and 25 selected fields. This is a curated crosswalk, not the full raw Run Selector export.

Source_SRA_RunInfo_Export.csv
  Source run-level metadata export retained as received (196 records; 47 columns in this file).

S2_Genus_Differential_Abundance.xlsx
S2_All_206_Tested_Genera.csv
  Complete exploratory genus-level DNA-versus-RNA comparison for all 206 tested genera, including raw P and BH-adjusted q values. See manuscript Methods for CLR transformation, pseudocount, test and filtering rules.

S3_Final_Taxonomy.tsv
  SILVA 138 classifier output for 37,994 ASVs. Columns: Feature ID, Taxon, Confidence. ASV-level taxonomy labels; counts are unique feature records, not read-weighted abundances.

S4_DADA2_Denoising_Statistics.tsv
  Per-sample DADA2 denoising statistics. Includes 196 sample rows plus a summary row where present in the source artifact; inspect row labels before calculating per-sample summaries.

Final_ASV_Feature_Table.biom
  Final sample-by-ASV count table in BIOM HDF5 format. Feature table UUID recorded in project provenance: bdaedcb3-627c-47d7-bda1-4c94eb8c9ed1.

Final_Representative_ASV_Sequences.fasta
  Final representative ASV sequences. Artifact UUID: 825d0fcc-2825-467e-a678-9d97b8267d92.

qiime2_provenance/
  QIIME 2 action provenance and environment YAML files extracted from the DADA2 and taxonomy artifacts. These describe the executed actions and software environment.

Important notes
1. Raw FASTQ files are not redistributed here; they remain available from NCBI SRA under SRP453394.
2. This package is an assembled supplementary-data package. It has not yet been deposited in a public repository and therefore has no DOI or persistent public URL.
3. The accession crosswalk and source RunInfo export are distinct files with different field counts; do not describe the 25-column crosswalk as the original raw export.
4. The genus-level screen is exploratory and was not adjusted for collection date. Interpret associations accordingly.
5. The feature table, representative sequences and taxonomy should be retained together as the final analysis outputs.
